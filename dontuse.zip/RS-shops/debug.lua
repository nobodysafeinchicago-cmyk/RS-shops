-- RS-Shops Debug Tool (Silent Mode)
-- Only runs if Config.Debug is explicitly set to true

if not Config.Debug then return end

CreateThread(function()
    repeat Wait(1000) until NetworkIsSessionStarted()
    Wait(1000)
    TriggerServerEvent('rs-shops:requestShops')
end)

RegisterNetEvent('rs-shops:client:setShops', function(list)
    if not Config.Debug then return end
    
    local count = list and #list or 0
    print(('RS-Shops DEBUG: Received %s shops'):format(count))
    
    if count > 0 then
        for i, s in ipairs(list) do
            local x = (s.coords and s.coords.x) or s.x or 0.0
            local y = (s.coords and s.coords.y) or s.y or 0.0
            local z = (s.coords and s.coords.z) or s.z or 0.0
            print(('[%s] %s | ped: %s | coords: %.2f, %.2f, %.2f')
                :format(s.id or '?', s.name or 'Unknown', s.ped_model or '???', x, y, z))
        end
    end
end)
