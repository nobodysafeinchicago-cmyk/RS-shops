fx_version 'cerulean'

shared_script "@SecureServe/src/module/module.lua"
shared_script "@SecureServe/src/module/module.js"
file "@SecureServe/secureserve.key"
game 'gta5'
lua54 'yes'

name 'rs-shops'
author 'Bestie & Rubenia'
description 'RS-Shops v2.0 - Ped-targeted shops with DB persistence (oxmysql), QBCore, ox_lib, ox_target, ox_inventory.'
version '2.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'client.lua',
    'debug.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

dependencies {
    'ox_lib',
    'ox_target',
    'qb-core',
    'ox_inventory'
}
