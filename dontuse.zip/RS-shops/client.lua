local QBCore = exports['qb-core']:GetCoreObject()

local spawnedPeds = {}
local targetZones = {}
local shops = {}
local nuiOpen = false

-- ===== Helpers =====
local function loadAnim(dict)
    if not dict or dict == '' then return end
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(0) end
end

local function deletePed(ped)
    if DoesEntityExist(ped) then
        SetEntityAsMissionEntity(ped, true, true)
        DeletePed(ped)
    end
end

local function clearAllPeds()
    for id, ped in pairs(spawnedPeds) do
        if DoesEntityExist(ped) then deletePed(ped) end
    end
    spawnedPeds = {}
end

local function clearAllZones()
    for id, _ in pairs(targetZones) do
        exports.ox_target:removeZone(id)
    end
    targetZones = {}
end

-- Accepts:
--  shop.coords: vector4 OR vec4 OR table{x,y,z,w/h}
--  OR flat fields: shop.x, shop.y, shop.z, shop.h
local function unpackCoords(shop)
    local x, y, z, h

    if shop.coords then
        local c = shop.coords
        if type(c) == 'vector4' or type(c) == 'vec4' then
            x, y, z, h = c.x, c.y, c.z, c.w
        elseif type(c) == 'table' then
            x, y, z = c.x or c[1], c.y or c[2], c.z or c[3]
            h = c.w or c.h or c[4] or 0.0
        end
    end

    x = x or shop.x
    y = y or shop.y
    z = z or shop.z
    h = h or shop.h or 0.0

    if not x or not y or not z then return nil end
    return x + 0.0, y + 0.0, z + 0.0, h + 0.0
end

local function getLabel(shop)
    return shop.name or shop.label or ('Shop %s'):format(shop.id or '?')
end

-- ===== Shop Interaction =====
local function openShop(shopId, shopName)
    if nuiOpen then return end
    nuiOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'open', shopId = shopId, shopName = shopName })
    TriggerServerEvent('rs-shops:requestItems', shopId)
end

-- ===== Sell Menu =====
local function openSellMenu(shopId, shopName)
    -- This is for PLAYERS to sell items, not admins to manage
    TriggerServerEvent('rs-shops:requestSellItems', shopId)
end

-- ===== Spawner =====
local function spawnPedForShop(shop)
    if not shop or not shop.id then return end
    if spawnedPeds[shop.id] and DoesEntityExist(spawnedPeds[shop.id]) then return end

    local cx, cy, cz, ch = unpackCoords(shop)
    if not cx then return end

    local model = shop.ped_model or Config.DefaultPedModel or 'mp_m_shopkeep_01'
    local modelHash = joaat(model)
    RequestModel(modelHash)
    local timeout = GetGameTimer() + 8000
    while not HasModelLoaded(modelHash) do
        Wait(0)
        if GetGameTimer() > timeout then
            return
        end
    end

    local ped = CreatePed(4, modelHash, cx, cy, cz - 1.0, ch or 0.0, false, false)
    SetEntityAsMissionEntity(ped, true, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetPedFleeAttributes(ped, 0, false)
    SetPedCanRagdoll(ped, false)

    if Config.PedAnim and Config.PedAnim.dict and Config.PedAnim.clip then
        loadAnim(Config.PedAnim.dict)
        TaskPlayAnim(ped, Config.PedAnim.dict, Config.PedAnim.clip, 8.0, -8.0, -1, 1, 0.0, false, false, false)
    else
        TaskStartScenarioInPlace(ped, "WORLD_HUMAN_STAND_IMPATIENT", 0, true)
    end

    local options = {}

    -- Determine interaction based on shop_type
    if shop.shop_type == 'sell' then
        -- SELL SHOP - Players sell items to shop (Pawn Shop)
        options[#options + 1] = {
            name = ('rs-shops:sell:%s'):format(shop.id),
            label = Config.SellToShopLabel or 'Sell Items',
            distance = 2.0,
            icon = 'fa-solid fa-hand-holding-dollar',
            onSelect = function()
                openSellMenu(shop.id, getLabel(shop))
            end
        }
    else
        -- BUY SHOP - Players buy items from shop (default)
        options[#options + 1] = {
            name = ('rs-shops:buy:%s'):format(shop.id),
            label = Config.TargetLabel or 'Open Shop',
            distance = 2.0,
            icon = Config.InteractionIcon,
            onSelect = function()
                openShop(shop.id, getLabel(shop))
            end
        }
    end

    exports.ox_target:addLocalEntity(ped, options)

    spawnedPeds[shop.id] = ped
    SetModelAsNoLongerNeeded(modelHash)
end

local function createZoneForShop(shop)
    if not shop or not shop.id then return end
    if targetZones[shop.id] then return end

    local cx, cy, cz = unpackCoords(shop)
    if not cx then return end

    local zoneId = ('rs-shops-zone:%s'):format(shop.id)
    
    local options = {}

    -- Determine interaction based on shop_type
    if shop.shop_type == 'sell' then
        -- SELL SHOP - Players sell items to shop (Pawn Shop)
        options[#options + 1] = {
            name = ('rs-shops:sell:%s'):format(shop.id),
            label = Config.SellToShopLabel or 'Sell Items',
            icon = 'fa-solid fa-hand-holding-dollar',
            distance = Config.InteractionDistance,
            onSelect = function()
                openSellMenu(shop.id, getLabel(shop))
            end
        }
    else
        -- BUY SHOP - Players buy items from shop (default)
        options[#options + 1] = {
            name = ('rs-shops:buy:%s'):format(shop.id),
            label = Config.TargetLabel or 'Open Shop',
            icon = Config.InteractionIcon,
            distance = Config.InteractionDistance,
            onSelect = function()
                openShop(shop.id, getLabel(shop))
            end
        }
    end
    
    exports.ox_target:addSphereZone({
        coords = vector3(cx, cy, cz),
        radius = Config.InteractionDistance,
        debug = false,
        options = options
    })

    targetZones[shop.id] = zoneId
end

local function spawnAllShops()
    clearAllPeds()
    clearAllZones()
    
    for _, shop in pairs(shops) do
        if shop.use_ped then
            spawnPedForShop(shop)
        else
            createZoneForShop(shop)
        end
    end
end

-- ===== NUI =====
RegisterNUICallback('close', function(_, cb)
    nuiOpen = false
    SetNuiFocus(false, false)
    cb(true)
end)

RegisterNUICallback('buyItem', function(data, cb)
    TriggerServerEvent('rs-shops:buyItem', data.shopId, data.item, data.qty)
    cb(true)
end)

-- ===== Receive items from server =====
RegisterNetEvent('rs-shops:client:sendItems', function(shopId, items)
    SendNUIMessage({
        action = 'items',
        items = items
    })
end)

-- ===== Shop list from server =====
RegisterNetEvent('rs-shops:client:setShops', function(list)
    shops = list or {}
    spawnAllShops()
end)

RegisterNetEvent('rs-shops:client:loadShops', function(list)
    shops = list or {}
    spawnAllShops()
end)

-- ===== Utility Functions =====
local function getNearestShop(radius)
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local nearest, dist = nil, radius or Config.NearestShopRadius or 7.5
    for _, s in pairs(shops) do
        local x,y,z = unpackCoords(s)
        if x then
            local d = #(coords - vector3(x,y,z))
            if d < dist then dist = d; nearest = s end
        end
    end
    return nearest
end

-- ========== RECEIVE SELL ITEMS AND SHOW MENU ==========
RegisterNetEvent('rs-shops:client:receiveSellItems', function(sellItems)
    if not sellItems or #sellItems == 0 then
        return QBCore.Functions.Notify('This shop does not buy any items', 'error')
    end

    -- Create a lookup table of items shop accepts
    local acceptedItems = {}
    for _, sellItem in ipairs(sellItems) do
        acceptedItems[sellItem.item] = sellItem.price
    end

    -- Get player's inventory
    local playerData = QBCore.Functions.GetPlayerData()
    if not playerData or not playerData.items then
        return QBCore.Functions.Notify('Unable to load inventory', 'error')
    end

    local options = {}
    
    -- Loop through player's inventory and show only items shop accepts
    for _, playerItem in pairs(playerData.items) do
        if playerItem and playerItem.name and acceptedItems[playerItem.name] then
            local price = acceptedItems[playerItem.name]
            local oxItem = exports.ox_inventory:Items(playerItem.name)
            local label = oxItem and oxItem.label or playerItem.name
            
            options[#options + 1] = {
                title = label,
                description = ('You have: %s | Shop pays: $%s each'):format(playerItem.amount or playerItem.count, price),
                icon = 'box',
                onSelect = function()
                    local maxAmount = playerItem.amount or playerItem.count or 1
                    local input = lib.inputDialog('Sell ' .. label, {
                        { type = 'number', label = 'Quantity', default = 1, min = 1, max = maxAmount, required = true }
                    })
                    
                    if not input then return end
                    
                    local qty = tonumber(input[1]) or 1
                    if qty > maxAmount then
                        QBCore.Functions.Notify('You do not have that many', 'error')
                        return
                    end
                    
                    local shop = getNearestShop()
                    if shop then
                        TriggerServerEvent('rs-shops:sellItem', shop.id, playerItem.name, qty)
                    end
                end
            }
        end
    end
    
    if #options == 0 then
        return QBCore.Functions.Notify('You have no items this shop wants', 'error')
    end
    
    lib.registerContext({
        id = 'rs_shop_sell_menu',
        title = 'Sell Items to Shop',
        options = options
    })
    
    lib.showContext('rs_shop_sell_menu')
end)

-- ========== MANAGE SELL ITEMS FUNCTION ==========
local function openSellItemsManager(shopId)
    TriggerServerEvent('rs-shops:admin:getSellItems', shopId)
end

-- ========== SHOP MANAGER MENU (ox_lib) ==========
local function openShopManager()
    local s = getNearestShop()
    if not s then 
        return QBCore.Functions.Notify('No shop nearby', 'error') 
    end

    local options = {
        {
            title = 'Edit Shop Settings',
            description = 'Name, type, ped model, currency, ownership',
            icon = 'gear',
            onSelect = function()
                TriggerServerEvent('rs-shops:admin:getShopData', s.id)
            end
        }
    }

    -- Show appropriate item management based on shop type
    if s.shop_type == 'sell' then
        -- SELL SHOP - Manage what shop buys from players
        options[#options + 1] = {
            title = 'Manage Sell Items',
            description = 'Items this shop buys from players',
            icon = 'hand-holding-dollar',
            onSelect = function()
                openSellItemsManager(s.id)
            end
        }
    else
        -- BUY SHOP - Manage what shop sells to players
        options[#options + 1] = {
            title = 'Manage Shop Items',
            description = 'Items players can purchase',
            icon = 'box',
            onSelect = function()
                TriggerServerEvent('rs-shops:admin:getShopItems', s.id)
            end
        }
    end

    -- Common options
    options[#options + 1] = {
        title = 'Update Position',
        description = 'Move shop to your current location',
        icon = 'location-dot',
        onSelect = function()
            local alert = lib.alertDialog({
                header = 'Update Position',
                content = 'Move this shop to your current location?',
                centered = true,
                cancel = true
            })
            if alert == 'confirm' then
                local ped = PlayerPedId()
                local coords = GetEntityCoords(ped)
                local heading = GetEntityHeading(ped)
                TriggerServerEvent('rs-shops:admin:updatePosition', s.id, vector4(coords.x, coords.y, coords.z, heading))
            end
        end
    }

    options[#options + 1] = {
        title = 'Delete Shop',
        description = 'Permanently remove this shop',
        icon = 'trash',
        iconColor = 'red',
        onSelect = function()
            local alert = lib.alertDialog({
                header = 'Delete Shop',
                content = 'Are you sure? This cannot be undone!',
                centered = true,
                cancel = true
            })
            if alert == 'confirm' then
                TriggerServerEvent('rs-shops:admin:deleteShop', s.id)
            end
        end
    }

    lib.registerContext({
        id = 'rs_shop_manager',
        title = ('Manage: %s'):format(getLabel(s)),
        options = options
    })

    lib.showContext('rs_shop_manager')
end

-- ========== RECEIVE SHOP DATA FOR EDITING ==========
RegisterNetEvent('rs-shops:client:receiveShopData', function(shopData)
    local currencyOptions = {}
    for _, curr in ipairs(Config.CurrencyTypes) do
        currencyOptions[#currencyOptions + 1] = {
            value = curr.value,
            label = curr.label
        }
    end

    local shopTypeOptions = {}
    for _, st in ipairs(Config.ShopTypes) do
        shopTypeOptions[#shopTypeOptions + 1] = {
            value = st.value,
            label = st.label
        }
    end

    local input = lib.inputDialog('Edit Shop Settings', {
        { type = 'input', label = 'Shop Name', default = shopData.name, required = true },
        { type = 'select', label = 'Shop Type', options = shopTypeOptions, default = shopData.shop_type or 'buy', required = true },
        { type = 'input', label = 'Owner CitizenID (leave blank for no owner)', default = shopData.owner_citizenid or '', placeholder = 'ABC12345' },
        { type = 'input', label = 'Ped Model', default = shopData.ped_model, placeholder = Config.DefaultPedModel },
        { type = 'select', label = 'Currency Type', options = currencyOptions, default = shopData.currency_type },
        { type = 'input', label = 'Currency Item (if type = item)', default = shopData.currency_item, placeholder = 'blood_money' },
        { type = 'checkbox', label = 'Use Ped', checked = shopData.use_ped == 1 }
    })

    if not input then return end

    TriggerServerEvent('rs-shops:admin:editShop', shopData.id, {
        name = input[1],
        shop_type = input[2],
        owner_citizenid = input[3] ~= '' and input[3] or nil,
        ped_model = input[4],
        currency_type = input[5],
        currency_item = input[6] ~= '' and input[6] or nil,
        use_ped = input[7]
    })
end)

-- ========== RECEIVE SHOP ITEMS FOR MANAGEMENT ==========
RegisterNetEvent('rs-shops:client:receiveShopItems', function(items)
    local s = getNearestShop()
    if not s then return end

    local options = {
        {
            title = 'Add New Item',
            description = 'Add a new item to this shop',
            icon = 'plus',
            iconColor = 'green',
            onSelect = function()
                local input = lib.inputDialog('Add Item', {
                    { type = 'input', label = 'Item Name (ox_inventory)', placeholder = 'water', required = true },
                    { type = 'number', label = 'Price', default = 10, min = 0, required = true },
                    { type = 'number', label = 'Stock (-1 = infinite)', default = -1, min = -1, required = true },
                    { type = 'input', label = 'Metadata (JSON)', placeholder = '{"serial":"ABC123"}' }
                })

                if not input then return end

                local metadata = nil
                if input[4] and input[4] ~= '' then
                    local success, parsed = pcall(json.decode, input[4])
                    if success then
                        metadata = parsed
                    else
                        QBCore.Functions.Notify('Invalid JSON metadata', 'error')
                        return
                    end
                end

                TriggerServerEvent('rs-shops:admin:addItem', s.id, {
                    item = input[1],
                    price = input[2],
                    stock = input[3],
                    metadata = metadata
                })
            end
        }
    }

    for _, item in ipairs(items) do
        local oxItem = exports.ox_inventory:Items(item.item)
        local label = oxItem and oxItem.label or item.item

        options[#options + 1] = {
            title = label,
            description = ('Price: $%s | Stock: %s'):format(item.price, item.stock == -1 and 'Infinite' or item.stock),
            icon = 'box',
            metadata = item.metadata and { { label = 'Has Metadata', value = 'Yes' } } or nil,
            onSelect = function()
                lib.registerContext({
                    id = 'rs_shop_item_actions',
                    title = label,
                    menu = 'rs_shop_items_list',
                    options = {
                        {
                            title = 'Edit Item',
                            icon = 'pen',
                            onSelect = function()
                                local metaStr = item.metadata or ''
                                if type(metaStr) == 'string' and metaStr ~= '' then
                                    -- Already a string, use as is
                                elseif type(metaStr) == 'table' then
                                    metaStr = json.encode(metaStr)
                                else
                                    metaStr = ''
                                end

                                local editInput = lib.inputDialog('Edit Item', {
                                    { type = 'number', label = 'Price', default = item.price, min = 0, required = true },
                                    { type = 'number', label = 'Stock (-1 = infinite)', default = item.stock, min = -1, required = true },
                                    { type = 'input', label = 'Metadata (JSON)', default = metaStr, placeholder = '{"serial":"ABC123"}' }
                                })

                                if not editInput then return end

                                local metadata = nil
                                if editInput[3] and editInput[3] ~= '' then
                                    local success, parsed = pcall(json.decode, editInput[3])
                                    if success then
                                        metadata = parsed
                                    else
                                        QBCore.Functions.Notify('Invalid JSON metadata', 'error')
                                        return
                                    end
                                end

                                TriggerServerEvent('rs-shops:admin:addItem', s.id, {
                                    item = item.item,
                                    price = editInput[1],
                                    stock = editInput[2],
                                    metadata = metadata
                                })
                            end
                        },
                        {
                            title = 'Remove Item',
                            icon = 'trash',
                            iconColor = 'red',
                            onSelect = function()
                                local alert = lib.alertDialog({
                                    header = 'Remove Item',
                                    content = ('Remove %s from shop?'):format(label),
                                    centered = true,
                                    cancel = true
                                })
                                if alert == 'confirm' then
                                    TriggerServerEvent('rs-shops:admin:removeItem', s.id, item.item)
                                end
                            end
                        }
                    }
                })
                lib.showContext('rs_shop_item_actions')
            end
        }
    end

    lib.registerContext({
        id = 'rs_shop_items_list',
        title = ('Items: %s'):format(getLabel(s)),
        menu = 'rs_shop_manager',
        options = options
    })

    lib.showContext('rs_shop_items_list')
end)

-- ========== RECEIVE ADMIN SELL ITEMS AND SHOW MENU ==========
RegisterNetEvent('rs-shops:client:receiveAdminSellItems', function(sellItems)
    local s = getNearestShop()
    if not s then return end

    local options = {
        {
            title = 'Add New Sell Item',
            description = 'Add item shop will buy from players',
            icon = 'plus',
            iconColor = 'green',
            onSelect = function()
                local input = lib.inputDialog('Add Sell Item', {
                    { type = 'input', label = 'Item Name (ox_inventory)', placeholder = 'water', required = true },
                    { type = 'number', label = 'Buy Price (what shop pays)', default = 5, min = 0, required = true }
                })

                if not input then return end

                TriggerServerEvent('rs-shops:admin:addSellItem', s.id, {
                    item = input[1],
                    price = input[2]
                })
            end
        }
    }

    for _, item in ipairs(sellItems) do
        local oxItem = exports.ox_inventory:Items(item.item)
        local label = oxItem and oxItem.label or item.item

        options[#options + 1] = {
            title = label,
            description = ('Shop pays: $%s'):format(item.price),
            icon = 'hand-holding-dollar',
            onSelect = function()
                lib.registerContext({
                    id = 'rs_shop_sell_item_actions',
                    title = label,
                    menu = 'rs_shop_sell_items_list',
                    options = {
                        {
                            title = 'Edit Sell Price',
                            icon = 'pen',
                            onSelect = function()
                                local editInput = lib.inputDialog('Edit Sell Price', {
                                    { type = 'number', label = 'Buy Price', default = item.price, min = 0, required = true }
                                })

                                if not editInput then return end

                                TriggerServerEvent('rs-shops:admin:addSellItem', s.id, {
                                    item = item.item,
                                    price = editInput[1]
                                })
                            end
                        },
                        {
                            title = 'Remove Sell Item',
                            icon = 'trash',
                            iconColor = 'red',
                            onSelect = function()
                                local alert = lib.alertDialog({
                                    header = 'Remove Sell Item',
                                    content = ('Stop buying %s from players?'):format(label),
                                    centered = true,
                                    cancel = true
                                })
                                if alert == 'confirm' then
                                    TriggerServerEvent('rs-shops:admin:removeSellItem', s.id, item.item)
                                end
                            end
                        }
                    }
                })
                lib.showContext('rs_shop_sell_item_actions')
            end
        }
    end

    lib.registerContext({
        id = 'rs_shop_sell_items_list',
        title = ('Sell Items: %s'):format(getLabel(s)),
        menu = 'rs_shop_manager',
        options = options
    })

    lib.showContext('rs_shop_sell_items_list')
end)

-- ========== CREATE SHOP COMMAND ==========
RegisterCommand('createshop', function()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)

    local currencyOptions = {}
    for _, curr in ipairs(Config.CurrencyTypes) do
        currencyOptions[#currencyOptions + 1] = {
            value = curr.value,
            label = curr.label
        }
    end

    local shopTypeOptions = {}
    for _, st in ipairs(Config.ShopTypes) do
        shopTypeOptions[#shopTypeOptions + 1] = {
            value = st.value,
            label = st.label
        }
    end

    local input = lib.inputDialog('Create Shop', {
        { type = 'input', label = 'Shop Name', placeholder = '24/7 Rockford', required = true },
        { type = 'select', label = 'Shop Type', options = shopTypeOptions, default = 'buy', required = true },
        { type = 'input', label = 'Owner CitizenID (optional)', placeholder = 'ABC12345' },
        { type = 'input', label = 'Ped Model', placeholder = Config.DefaultPedModel or 'mp_m_shopkeep_01' },
        { type = 'select', label = 'Currency Type', options = currencyOptions, default = 'cash' },
        { type = 'input', label = 'Currency Item (if type = item)', placeholder = 'blood_money' },
        { type = 'checkbox', label = 'Use Ped', checked = true }
    })

    if not input then return end

    TriggerServerEvent('rs-shops:admin:createShop', {
        name = input[1],
        coords = vector4(coords.x, coords.y, coords.z, heading),
        shop_type = input[2],
        owner_citizenid = input[3] ~= '' and input[3] or nil,
        ped_model = input[4] ~= '' and input[4] or (Config.DefaultPedModel or 'mp_m_shopkeep_01'),
        currency_type = input[5],
        currency_item = input[6] ~= '' and input[6] or nil,
        use_ped = input[7]
    })
end)

-- ========== SHOP MANAGER COMMAND ==========
RegisterCommand('shopmanager', function()
    openShopManager()
end)

RegisterCommand('reloadshops', function()
    TriggerServerEvent('rs-shops:requestShops')
end)

-- ===== Initial sync & cleanup =====
CreateThread(function()
    Wait(1200)
    TriggerServerEvent('rs-shops:requestShops')
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    clearAllPeds()
    clearAllZones()
    if nuiOpen then
        SendNUIMessage({ action = 'forceClose' })
        SetNuiFocus(false, false)
    end
end)
