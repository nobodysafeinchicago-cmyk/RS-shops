-- =====================================================
-- RS-Shops v2.2 - Complete Installation SQL
-- Author: RubeniaSalas
-- https://github.com/RubeniaSalas/rs-shops
-- =====================================================
-- This file creates all required tables and columns
-- Safe to run multiple times (won't delete data)
-- =====================================================

-- ========== CREATE MAIN SHOPS TABLE ==========
CREATE TABLE IF NOT EXISTS `rs_shops` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `x` FLOAT NOT NULL,
    `y` FLOAT NOT NULL,
    `z` FLOAT NOT NULL,
    `h` FLOAT DEFAULT 0.0,
    `ped_model` VARCHAR(50) DEFAULT 'mp_m_shopkeep_01',
    `shop_type` VARCHAR(20) DEFAULT 'buy',
    `currency_type` VARCHAR(20) DEFAULT 'cash',
    `currency_item` VARCHAR(50) DEFAULT NULL,
    `use_ped` TINYINT(1) DEFAULT 1,
    `owner_citizenid` VARCHAR(50) DEFAULT NULL,
    INDEX `idx_owner` (`owner_citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== CREATE SHOP ITEMS TABLE (ITEMS SHOP SELLS) ==========
CREATE TABLE IF NOT EXISTS `rs_shop_items` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `shop_id` INT NOT NULL,
    `item` VARCHAR(50) NOT NULL,
    `price` INT NOT NULL DEFAULT 0,
    `stock` INT DEFAULT -1,
    `metadata` TEXT DEFAULT NULL,
    UNIQUE KEY `uniq_shop_item` (`shop_id`, `item`),
    INDEX `idx_shop_id` (`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== CREATE SELL ITEMS TABLE (ITEMS SHOP BUYS - PAWN) ==========
CREATE TABLE IF NOT EXISTS `rs_shop_sell_items` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `shop_id` INT NOT NULL,
    `item` VARCHAR(50) NOT NULL,
    `price` INT NOT NULL DEFAULT 0,
    UNIQUE KEY `uniq_shop_sell_item` (`shop_id`, `item`),
    INDEX `idx_shop_id` (`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== CREATE TRANSACTION LOG TABLE ==========
CREATE TABLE IF NOT EXISTS `rs_shop_txn` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `shop_id` INT NOT NULL,
    `citizenid` VARCHAR(50) NOT NULL,
    `item` VARCHAR(50) NOT NULL,
    `qty` INT NOT NULL,
    `total` INT NOT NULL,
    `metadata` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_shop_id` (`shop_id`),
    INDEX `idx_citizenid` (`citizenid`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== ADD COLUMNS IF MISSING (SAFE UPGRADES) ==========

-- Add ped_model if missing
SET @dbname = DATABASE();
SET @tablename = 'rs_shops';
SET @columnname = 'ped_model';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " VARCHAR(50) DEFAULT 'mp_m_shopkeep_01';")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add shop_type if missing
SET @columnname = 'shop_type';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " VARCHAR(20) DEFAULT 'buy';")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add currency_type if missing
SET @columnname = 'currency_type';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " VARCHAR(20) DEFAULT 'cash';")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add currency_item if missing
SET @columnname = 'currency_item';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " VARCHAR(50) DEFAULT NULL;")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add use_ped if missing
SET @columnname = 'use_ped';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " TINYINT(1) DEFAULT 1;")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add owner_citizenid if missing
SET @columnname = 'owner_citizenid';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " VARCHAR(50) DEFAULT NULL;")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add metadata to rs_shop_items if missing
SET @tablename = 'rs_shop_items';
SET @columnname = 'metadata';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " TEXT DEFAULT NULL;")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add metadata to rs_shop_txn if missing
SET @tablename = 'rs_shop_txn';
SET @columnname = 'metadata';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " TEXT DEFAULT NULL;")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- ========== VERIFICATION ==========
-- Run this to verify installation:
SELECT 'rs_shops table exists' as status FROM rs_shops LIMIT 1;
SELECT 'rs_shop_items table exists' as status FROM rs_shop_items LIMIT 1;
SELECT 'rs_shop_sell_items table exists' as status FROM rs_shop_sell_items LIMIT 1;
SELECT 'rs_shop_txn table exists' as status FROM rs_shop_txn LIMIT 1;

-- ========== INSTALLATION COMPLETE ==========
-- You should see 4 "exists" messages above
-- If any errors occurred, check your database user permissions
-- =====================================================
