Config = {}

Config.Debug = false  -- Set to true only when troubleshooting
Config.NearestShopRadius = 7.5
Config.DefaultPedModel = 'mp_m_shopkeep_01'

Config.PedAnim = {
    dict = 'amb@world_human_hang_out_street@male_a@idle_a',
    clip = 'idle_a'
}

Config.TargetLabel = 'Open Shop'
Config.DefaultCurrency = 'cash' -- Default: 'cash', 'bank', or 'item'

-- Available currency types for shops
Config.CurrencyTypes = {
    { value = 'cash',  label = 'Cash' },
    { value = 'bank',  label = 'Bank' },
    { value = 'item',  label = 'Custom Item (e.g. blood_money)' }
}

-- âœ… ACE-only permission (your server.cfg uses: add_ace group.admin rs.shops allow)
Config.AdminAce = 'rs.shops'

-- Interaction settings for ped-less shops
Config.InteractionDistance = 2.0
Config.InteractionIcon = 'fa-solid fa-basket-shopping'

-- Shop ownership settings
Config.AllowOwnership = true  -- Enable/disable shop ownership system
Config.OwnerCanEditOnly = true  -- If true, only owner can use /shopmanager

-- Shop type options
Config.ShopTypes = {
    { value = 'buy',  label = 'Buy Shop (Players purchase items)' },
    { value = 'sell', label = 'Sell Shop (Players sell items - Pawn)' }
}

-- Item selling (pawn shop) settings
Config.DefaultSellMultiplier = 0.50  -- Default 50% of item value when selling to shop
Config.SellToShopLabel = 'Sell Items'  -- Target label for selling items
