const wrap = document.getElementById('wrap');
const titleEl = document.getElementById('title');
const itemsEl = document.getElementById('items');
const closeBtn = document.getElementById('close');

let currentShopId = null;

window.addEventListener('message', (e) => {
  const data = e.data || {};
  if (data.action === 'open') {
    currentShopId = data.shopId;
    titleEl.textContent = data.shopName || 'Shop';
    itemsEl.innerHTML = '';
    wrap.classList.remove('hidden');
  } else if (data.action === 'items') {
    // render items
    itemsEl.innerHTML = '';
    (data.items || []).forEach(it => {
      const card = document.createElement('div');
      card.className = 'card';
      
      // Get the item name (handle both 'item' and 'name' properties)
      const itemName = it.name || it.item;
      
      // Construct image path the same way ox_inventory does
      const imgPath = `nui://ox_inventory/web/images/${itemName}.png`;
      
      card.innerHTML = `
        <img src="${imgPath}" alt="${it.label}" class="item-image" onerror="this.style.display='none'">
        <h4>${it.label}</h4>
        <div class="muted">$${it.price} ${it.stock === -1 ? '' : '• Stock: ' + it.stock}</div>
        <div class="row">
          <input type="number" min="1" value="1" />
          <button class="btn">Buy</button>
        </div>
      `;
      const input = card.querySelector('input');
      const btn = card.querySelector('button');
      btn.addEventListener('click', () => {
        const qty = Math.max(1, parseInt(input.value || '1', 10));
        fetch(`https://rs-shops/buyItem`, {
          method: 'POST',
          headers: {'Content-Type':'application/json'},
          body: JSON.stringify({ shopId: currentShopId, item: itemName, qty })
        });
      });
      itemsEl.appendChild(card);
    });
  }
});

closeBtn.addEventListener('click', () => {
  fetch('https://rs-shops/close', { method: 'POST', body: '{}' });
  wrap.classList.add('hidden');
});

window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeBtn.click();
  }
});
