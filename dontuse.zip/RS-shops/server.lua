local QBCore = exports['qb-core']:GetCoreObject()

-- Cache
local shops = {}

-- âœ… ACE-only admin check
local function isAdmin(src)
    return IsPlayerAceAllowed(src, Config.AdminAce)
end

-- âœ… Shop ownership check
local function isShopOwner(src, shopId)
    if not Config.AllowOwnership then return true end  -- If ownership disabled, everyone can manage
    if isAdmin(src) then return true end  -- Admins can always manage
    
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end
    
    for _, shop in ipairs(shops) do
        if shop.id == shopId then
            if not shop.owner_citizenid then return true end  -- No owner set = anyone can manage
            return shop.owner_citizenid == Player.PlayerData.citizenid
        end
    end
    return false
end

-- Utility: number parser
local function toNum(v, d)
    v = tonumber(v)
    return v ~= nil and v or d
end

-- Utility: safely parse JSON metadata
local function parseMetadata(str)
    if not str or str == '' then return nil end
    local success, result = pcall(json.decode, str)
    return success and result or nil
end

-- Utility: fetch all shops from DB
local function loadShopsFromDB(cb)
    MySQL.query([[
        SELECT id, name, x, y, z, h, 
               COALESCE(ped_model, ?) as ped_model, 
               shop_type,
               COALESCE(currency_type, 'cash') as currency_type,
               currency_item,
               COALESCE(use_ped, 1) as use_ped,
               owner_citizenid
        FROM rs_shops
    ]], {
        Config.DefaultPedModel
    }, function(rows)
        shops = {}
        for _, r in ipairs(rows) do
            shops[#shops+1] = {
                id = r.id,
                name = r.name,
                x = toNum(r.x, 0.0),
                y = toNum(r.y, 0.0),
                z = toNum(r.z, 0.0),
                h = toNum(r.h, 0.0),
                ped_model = r.ped_model,
                shop_type = r.shop_type,
                currency_type = r.currency_type or 'cash',
                currency_item = r.currency_item,
                use_ped = r.use_ped == 1,
                owner_citizenid = r.owner_citizenid
            }
        end
        if cb then cb(shops) end
    end)
end

-- Utility: send all shops to everyone OR a single player (safe version)
local function broadcastShops(target)
    local formatted = {}

    for _, r in ipairs(shops) do
        local x, y, z = toNum(r.x, 0.0), toNum(r.y, 0.0), toNum(r.z, 0.0)
        local h = toNum(r.h, 0.0)

        if x ~= 0.0 or y ~= 0.0 or z ~= 0.0 then
            formatted[#formatted + 1] = {
                id = r.id,
                name = r.name,
                label = r.name,
                coords = vector4(x, y, z, h),
                ped_model = r.ped_model or Config.DefaultPedModel,
                shop_type = r.shop_type or 'buy',
                currency_type = r.currency_type or 'cash',
                currency_item = r.currency_item,
                use_ped = r.use_ped,
                owner_citizenid = r.owner_citizenid
            }
        end
    end

    if target then
        TriggerClientEvent('rs-shops:client:setShops', target, formatted)
    else
        TriggerClientEvent('rs-shops:client:setShops', -1, formatted)
    end
end

-- Startup: ensure columns exist, then load shops
CreateThread(function()
    Wait(1000)
    
    -- Check and add ped_model
    MySQL.query('SHOW COLUMNS FROM rs_shops LIKE "ped_model"', {}, function(result)
        if not result or #result == 0 then
            MySQL.query('ALTER TABLE rs_shops ADD COLUMN ped_model VARCHAR(50) DEFAULT ?', { Config.DefaultPedModel })
        end
    end)

    -- Check and add currency_type
    MySQL.query('SHOW COLUMNS FROM rs_shops LIKE "currency_type"', {}, function(result)
        if not result or #result == 0 then
            MySQL.query('ALTER TABLE rs_shops ADD COLUMN currency_type VARCHAR(20) DEFAULT "cash"')
        end
    end)

    -- Check and add currency_item
    MySQL.query('SHOW COLUMNS FROM rs_shops LIKE "currency_item"', {}, function(result)
        if not result or #result == 0 then
            MySQL.query('ALTER TABLE rs_shops ADD COLUMN currency_item VARCHAR(50) DEFAULT NULL')
        end
    end)

    -- Check and add use_ped
    MySQL.query('SHOW COLUMNS FROM rs_shops LIKE "use_ped"', {}, function(result)
        if not result or #result == 0 then
            MySQL.query('ALTER TABLE rs_shops ADD COLUMN use_ped TINYINT(1) DEFAULT 1')
        end
    end)

    -- Check and add metadata to shop_items
    MySQL.query('SHOW COLUMNS FROM rs_shop_items LIKE "metadata"', {}, function(result)
        if not result or #result == 0 then
            MySQL.query('ALTER TABLE rs_shop_items ADD COLUMN metadata TEXT DEFAULT NULL')
        end
    end)

    -- Check and add owner_citizenid
    MySQL.query('SHOW COLUMNS FROM rs_shops LIKE "owner_citizenid"', {}, function(result)
        if not result or #result == 0 then
            MySQL.query('ALTER TABLE rs_shops ADD COLUMN owner_citizenid VARCHAR(50) DEFAULT NULL')
        end
    end)

    -- Create rs_shop_sell_items table if not exists (without foreign key to avoid deadlock)
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS rs_shop_sell_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            shop_id INT NOT NULL,
            item VARCHAR(50) NOT NULL,
            price INT NOT NULL DEFAULT 0,
            UNIQUE KEY uniq_shop_sell_item (shop_id, item),
            KEY idx_shop_id (shop_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ]])

    -- Ensure unique index
    MySQL.query('SHOW INDEX FROM rs_shop_items WHERE Key_name = "uniq_shop_item"', {}, function(idx)
        if not idx or #idx == 0 then
            MySQL.query('ALTER TABLE rs_shop_items ADD UNIQUE KEY uniq_shop_item (shop_id, item)')
        end
    end)

    loadShopsFromDB(function()
        broadcastShops()
    end)
end)

-- Net: client requests shops
RegisterNetEvent('rs-shops:requestShops', function()
    local src = source
    loadShopsFromDB(function()
        broadcastShops(src)
    end)
end)

-- Net: client requests items for a shop (open UI)
RegisterNetEvent('rs-shops:requestItems', function(shopId)
    local src = source
    MySQL.query('SELECT id, item, price, stock, metadata FROM rs_shop_items WHERE shop_id = ?', { shopId }, function(rows)
        local items = {}
        for _, r in ipairs(rows) do
            local item = exports.ox_inventory:Items(r.item)
            if item then
                items[#items+1] = {
                    id = r.id, 
                    name = r.item, 
                    label = item.label or r.item,
                    price = r.price, 
                    stock = r.stock or -1,
                    metadata = parseMetadata(r.metadata)
                }
            end
        end
        TriggerClientEvent('rs-shops:client:sendItems', src, shopId, items)
    end)
end)

-- Purchase handler with currency support
RegisterNetEvent('rs-shops:buyItem', function(shopId, itemName, qty)
    local src = source
    qty = tonumber(qty) or 1
    if qty < 1 then qty = 1 end

    -- Get shop info for currency
    local shop = nil
    for _, s in ipairs(shops) do
        if s.id == shopId then
            shop = s
            break
        end
    end

    if not shop then
        return TriggerClientEvent('QBCore:Notify', src, 'Shop not found', 'error')
    end

    MySQL.query('SELECT id, price, stock, metadata FROM rs_shop_items WHERE shop_id = ? AND item = ?', { shopId, itemName }, function(rows)
        if not rows or not rows[1] then
            return TriggerClientEvent('QBCore:Notify', src, 'Item not found', 'error')
        end
        local row = rows[1]
        local price = row.price or 0
        local stock = row.stock or -1
        local metadata = parseMetadata(row.metadata)

        if stock ~= -1 and stock < qty then
            return TriggerClientEvent('QBCore:Notify', src, 'Not enough stock', 'error')
        end

        local total = price * qty
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end

        local currencyType = shop.currency_type or 'cash'
        local currencyItem = shop.currency_item
        local paymentSuccess = false

        -- Handle payment based on currency type
        if currencyType == 'item' and currencyItem then
            -- Custom item payment (e.g. blood_money)
            local itemCount = exports.ox_inventory:GetItemCount(src, currencyItem)
            if itemCount >= total then
                if exports.ox_inventory:RemoveItem(src, currencyItem, total) then
                    paymentSuccess = true
                end
            else
                return TriggerClientEvent('QBCore:Notify', src, ('Not enough %s'):format(currencyItem), 'error')
            end
        else
            -- Cash or bank payment
            if Player.Functions.RemoveMoney(currencyType, total, 'rs-shops purchase') then
                paymentSuccess = true
            end
        end

        if paymentSuccess then
            local ok = exports.ox_inventory:AddItem(src, itemName, qty, metadata, nil)
            if not ok then
                -- Refund on failure
                if currencyType == 'item' and currencyItem then
                    exports.ox_inventory:AddItem(src, currencyItem, total)
                else
                    Player.Functions.AddMoney(currencyType, total, 'rs-shops refund')
                end
                return TriggerClientEvent('QBCore:Notify', src, 'Failed to add item', 'error')
            end

            if stock ~= -1 then
                MySQL.update('UPDATE rs_shop_items SET stock = stock - ? WHERE id = ?', { qty, row.id })
            end

            local metaJson = metadata and json.encode(metadata) or nil
            MySQL.insert('INSERT INTO rs_shop_txn (shop_id, citizenid, item, qty, total, metadata) VALUES (?, ?, ?, ?, ?, ?)', {
                shopId, Player.PlayerData.citizenid, itemName, qty, total, metaJson
            })

            local currencyLabel = currencyType
            if currencyType == 'item' and currencyItem then
                local itemDef = exports.ox_inventory:Items(currencyItem)
                currencyLabel = itemDef and itemDef.label or currencyItem
            end

            TriggerClientEvent('QBCore:Notify', src, ('Purchased %sx %s for %s %s'):format(qty, itemName, total, currencyLabel), 'success')
        else
            TriggerClientEvent('QBCore:Notify', src, 'Payment failed', 'error')
        end
    end)
end)

-- ========== SELL ITEM TO SHOP ==========
RegisterNetEvent('rs-shops:sellItem', function(shopId, itemName, qty)
    local src = source
    qty = tonumber(qty) or 1
    if qty < 1 then qty = 1 end

    -- Get shop info
    local shop = nil
    for _, s in ipairs(shops) do
        if s.id == shopId then
            shop = s
            break
        end
    end

    if not shop then
        return TriggerClientEvent('QBCore:Notify', src, 'Shop not found', 'error')
    end

    if shop.shop_type ~= 'sell' then
        return TriggerClientEvent('QBCore:Notify', src, 'This shop does not buy items', 'error')
    end

    -- Check if shop accepts this item
    MySQL.query('SELECT id, price FROM rs_shop_sell_items WHERE shop_id = ? AND item = ?', { shopId, itemName }, function(rows)
        if not rows or not rows[1] then
            return TriggerClientEvent('QBCore:Notify', src, 'Shop does not buy this item', 'error')
        end

        local sellPrice = rows[1].price or 0
        local total = sellPrice * qty

        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end

        -- Check if player has the item
        local itemCount = exports.ox_inventory:GetItemCount(src, itemName)
        if itemCount < qty then
            return TriggerClientEvent('QBCore:Notify', src, 'You do not have enough of this item', 'error')
        end

        -- Remove item from player
        if not exports.ox_inventory:RemoveItem(src, itemName, qty) then
            return TriggerClientEvent('QBCore:Notify', src, 'Failed to remove item', 'error')
        end

        -- Give payment based on shop currency type
        local currencyType = shop.currency_type or 'cash'
        local currencyItem = shop.currency_item

        if currencyType == 'item' and currencyItem then
            exports.ox_inventory:AddItem(src, currencyItem, total)
        else
            Player.Functions.AddMoney(currencyType, total, 'rs-shops sell')
        end

        -- Log transaction
        MySQL.insert('INSERT INTO rs_shop_txn (shop_id, citizenid, item, qty, total, metadata) VALUES (?, ?, ?, ?, ?, ?)', {
            shopId, Player.PlayerData.citizenid, itemName, -qty, -total, json.encode({type = 'sell'})
        })

        local currencyLabel = currencyType
        if currencyType == 'item' and currencyItem then
            local itemDef = exports.ox_inventory:Items(currencyItem)
            currencyLabel = itemDef and itemDef.label or currencyItem
        end

        TriggerClientEvent('QBCore:Notify', src, ('Sold %sx %s for %s %s'):format(qty, itemName, total, currencyLabel), 'success')

        -- If shop has owner, notify them (optional)
        if shop.owner_citizenid then
            local Owner = QBCore.Functions.GetPlayerByCitizenId(shop.owner_citizenid)
            if Owner then
                TriggerClientEvent('QBCore:Notify', Owner.PlayerData.source, 
                    ('Someone sold %sx %s to your shop'):format(qty, itemName), 'info')
            end
        end
    end)
end)

-- ========== PLAYER: Get sell items (for selling menu) ==========
RegisterNetEvent('rs-shops:requestSellItems', function(shopId)
    local src = source
    
    MySQL.query('SELECT id, item, price FROM rs_shop_sell_items WHERE shop_id = ? ORDER BY item', { shopId }, function(rows)
        local items = {}
        for _, r in ipairs(rows) do
            items[#items+1] = {
                id = r.id,
                item = r.item,
                price = r.price
            }
        end
        TriggerClientEvent('rs-shops:client:receiveSellItems', src, items)
    end)
end)

-- ========== ADMIN: Get shop data for menu ==========
RegisterNetEvent('rs-shops:admin:getShopData', function(shopId)
    local src = source
    if not isShopOwner(src, shopId) then
        return TriggerClientEvent('QBCore:Notify', src, 'No permissions', 'error')
    end

    MySQL.query([[
        SELECT id, name, x, y, z, h, ped_model, shop_type, 
               currency_type, currency_item, use_ped,
               owner_citizenid 
        FROM rs_shops WHERE id = ?
    ]], { shopId }, function(rows)
        if rows and rows[1] then
            TriggerClientEvent('rs-shops:client:receiveShopData', src, rows[1])
        end
    end)
end)

-- ========== ADMIN: Get shop items for menu ==========
RegisterNetEvent('rs-shops:admin:getShopItems', function(shopId)
    local src = source
    if not isShopOwner(src, shopId) then return end

    MySQL.query('SELECT id, item, price, stock, metadata FROM rs_shop_items WHERE shop_id = ? ORDER BY item', { shopId }, function(rows)
        local items = {}
        for _, r in ipairs(rows) do
            items[#items+1] = {
                id = r.id,
                item = r.item,
                price = r.price,
                stock = r.stock,
                metadata = r.metadata
            }
        end
        TriggerClientEvent('rs-shops:client:receiveShopItems', src, items)
    end)
end)

-- ========== ADMIN: Get sell items for menu ==========
RegisterNetEvent('rs-shops:admin:getSellItems', function(shopId)
    local src = source
    if not isShopOwner(src, shopId) then return end

    MySQL.query('SELECT id, item, price FROM rs_shop_sell_items WHERE shop_id = ? ORDER BY item', { shopId }, function(rows)
        local items = {}
        for _, r in ipairs(rows) do
            items[#items+1] = {
                id = r.id,
                item = r.item,
                price = r.price
            }
        end
        TriggerClientEvent('rs-shops:client:receiveAdminSellItems', src, items)
    end)
end)

-- ========== ADMIN: Create shop ==========
RegisterNetEvent('rs-shops:admin:createShop', function(data)
    local src = source
    if not isAdmin(src) then
        return TriggerClientEvent('QBCore:Notify', src, 'No permissions', 'error')
    end

    local name = data.name or 'Shop'
    local ped_model = data.ped_model or Config.DefaultPedModel
    local shop_type = data.shop_type or 'buy'
    local currency_type = data.currency_type or 'cash'
    local currency_item = data.currency_item
    local use_ped = data.use_ped ~= false and 1 or 0
    local owner_citizenid = data.owner_citizenid  -- Can be nil

    local x, y, z, h
    if data.coords then
        x, y, z, h = data.coords.x or data.coords[1],
                     data.coords.y or data.coords[2],
                     data.coords.z or data.coords[3],
                     data.coords.w or data.coords.h or data.coords[4] or 0.0
    else
        x, y, z, h = data.x, data.y, data.z, data.h
    end

    MySQL.insert([[
        INSERT INTO rs_shops (name, x, y, z, h, ped_model, shop_type, currency_type, currency_item, use_ped, owner_citizenid) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ]], {
        name, x, y, z, h, ped_model, shop_type, currency_type, currency_item, use_ped, owner_citizenid
    }, function(id)
        if id then
            loadShopsFromDB(function()
                broadcastShops()
            end)
            TriggerClientEvent('QBCore:Notify', src, ('Created shop "%s"'):format(name), 'success')
        else
            TriggerClientEvent('QBCore:Notify', src, 'DB insert failed', 'error')
        end
    end)
end)

-- ========== ADMIN: Edit shop settings ==========
RegisterNetEvent('rs-shops:admin:editShop', function(shopId, data)
    local src = source
    if not isShopOwner(src, shopId) then
        return TriggerClientEvent('QBCore:Notify', src, 'No permissions', 'error')
    end

    MySQL.update([[
        UPDATE rs_shops 
        SET name = ?, ped_model = ?, shop_type = ?, 
            currency_type = ?, currency_item = ?, use_ped = ?,
            owner_citizenid = ?
        WHERE id = ?
    ]], {
        data.name, data.ped_model, data.shop_type, 
        data.currency_type, data.currency_item, data.use_ped and 1 or 0,
        data.owner_citizenid,
        shopId
    }, function()
        loadShopsFromDB(function()
            broadcastShops()
        end)
        TriggerClientEvent('QBCore:Notify', src, 'Shop updated', 'success')
    end)
end)

-- ========== ADMIN: Update shop position ==========
RegisterNetEvent('rs-shops:admin:updatePosition', function(shopId, coords)
    local src = source
    if not isShopOwner(src, shopId) then return end

    local x, y, z, h = coords.x, coords.y, coords.z, coords.w or coords.h or 0.0

    MySQL.update('UPDATE rs_shops SET x = ?, y = ?, z = ?, h = ? WHERE id = ?', {
        x, y, z, h, shopId
    }, function()
        loadShopsFromDB(function()
            broadcastShops()
        end)
        TriggerClientEvent('QBCore:Notify', src, 'Position updated', 'success')
    end)
end)

-- ========== ADMIN: Add or update item ==========
RegisterNetEvent('rs-shops:admin:addItem', function(shopId, itemData)
    local src = source
    if not isShopOwner(src, shopId) then
        return TriggerClientEvent('QBCore:Notify', src, 'No permissions', 'error')
    end

    local itemName = (itemData.item or ''):lower()
    local item = exports.ox_inventory:Items(itemName)
    if not item then
        return TriggerClientEvent('QBCore:Notify', src, ('Item "%s" not found in ox_inventory'):format(itemName), 'error')
    end

    local price = tonumber(itemData.price) or 0
    local stock = tonumber(itemData.stock) or -1
    local metaJson = itemData.metadata and json.encode(itemData.metadata) or nil

    MySQL.query('SELECT id FROM rs_shop_items WHERE shop_id = ? AND item = ?', { shopId, itemName }, function(rows)
        if rows and rows[1] then
            MySQL.update('UPDATE rs_shop_items SET price = ?, stock = ?, metadata = ? WHERE id = ?', { 
                price, stock, metaJson, rows[1].id 
            }, function()
                TriggerClientEvent('QBCore:Notify', src, 'Item updated', 'success')
            end)
        else
            MySQL.insert('INSERT INTO rs_shop_items (shop_id, item, price, stock, metadata) VALUES (?, ?, ?, ?, ?)', {
                shopId, itemName, price, stock, metaJson
            }, function()
                TriggerClientEvent('QBCore:Notify', src, 'Item added', 'success')
            end)
        end
    end)
end)

-- ========== ADMIN: Remove item from shop ==========
RegisterNetEvent('rs-shops:admin:removeItem', function(shopId, itemName)
    local src = source
    if not isShopOwner(src, shopId) then return end

    MySQL.update('DELETE FROM rs_shop_items WHERE shop_id = ? AND item = ?', { shopId, itemName }, function(affected)
        if affected > 0 then
            TriggerClientEvent('QBCore:Notify', src, 'Item removed', 'success')
        else
            TriggerClientEvent('QBCore:Notify', src, 'Item not found', 'error')
        end
    end)
end)

-- ========== ADMIN: Add or update sell item ==========
RegisterNetEvent('rs-shops:admin:addSellItem', function(shopId, itemData)
    local src = source
    if not isShopOwner(src, shopId) then
        return TriggerClientEvent('QBCore:Notify', src, 'No permissions', 'error')
    end

    local itemName = (itemData.item or ''):lower()
    local item = exports.ox_inventory:Items(itemName)
    if not item then
        return TriggerClientEvent('QBCore:Notify', src, ('Item "%s" not found in ox_inventory'):format(itemName), 'error')
    end

    local price = tonumber(itemData.price) or 0

    MySQL.query('SELECT id FROM rs_shop_sell_items WHERE shop_id = ? AND item = ?', { shopId, itemName }, function(rows)
        if rows and rows[1] then
            MySQL.update('UPDATE rs_shop_sell_items SET price = ? WHERE id = ?', { 
                price, rows[1].id 
            }, function()
                TriggerClientEvent('QBCore:Notify', src, 'Sell item updated', 'success')
            end)
        else
            MySQL.insert('INSERT INTO rs_shop_sell_items (shop_id, item, price) VALUES (?, ?, ?)', {
                shopId, itemName, price
            }, function()
                TriggerClientEvent('QBCore:Notify', src, 'Sell item added', 'success')
            end)
        end
    end)
end)

-- ========== ADMIN: Remove sell item ==========
RegisterNetEvent('rs-shops:admin:removeSellItem', function(shopId, itemName)
    local src = source
    if not isShopOwner(src, shopId) then return end

    MySQL.update('DELETE FROM rs_shop_sell_items WHERE shop_id = ? AND item = ?', { shopId, itemName }, function(affected)
        if affected > 0 then
            TriggerClientEvent('QBCore:Notify', src, 'Sell item removed', 'success')
        else
            TriggerClientEvent('QBCore:Notify', src, 'Sell item not found', 'error')
        end
    end)
end)

-- ========== ADMIN: Delete shop ==========
RegisterNetEvent('rs-shops:admin:deleteShop', function(shopId)
    local src = source
    if not isShopOwner(src, shopId) then
        return TriggerClientEvent('QBCore:Notify', src, 'No permissions', 'error')
    end
    
    -- Delete in proper order to avoid deadlock
    MySQL.query('DELETE FROM rs_shop_sell_items WHERE shop_id = ?', { shopId }, function()
        MySQL.query('DELETE FROM rs_shop_items WHERE shop_id = ?', { shopId }, function()
            MySQL.query('DELETE FROM rs_shops WHERE id = ?', { shopId }, function()
                loadShopsFromDB(function()
                    broadcastShops()
                end)
                TriggerClientEvent('QBCore:Notify', src, 'Shop deleted', 'success')
            end)
        end)
    end)
end)
